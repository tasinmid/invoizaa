import express from 'express';
import fs from 'fs';
import path from 'path';

const router = express.Router();

// Define the templates directory path
// Using path.resolve to get an absolute path is more robust
const templatesDir = path.resolve(process.cwd(), 'templates');

const templateImageMap = {
    "template1": "https://i.ibb.co.com/G3RstYP6/template1.png",
    "template2": "https://i.ibb.co.com/21F0zhhX/template2.png",
    "template3": "https://i.ibb.co.com/fVyTZCCg/template3.png",
    "template4": "https://i.ibb.co.com/TDgRgsdF/template4.png",
    "template5": "https://i.ibb.co.com/rK3zPCd9/template5.png",
    "template6": "https://i.ibb.co.com/gFS0GFz8/template6.png",
    "template7": "https://i.ibb.co.com/kg0VBP2S/template7.png"
};

router.get('/l', (req, res) => {
    fs.readdir(templatesDir, (err, files) => {
        if (err) {
            console.error("Error reading templates directory:", err);
            return res.status(500).json({ error: 'Could not retrieve templates' });
        }

        const templates = files
            .filter(file => file.endsWith('.html'))
            .map(file => {
                const templateName = file.replace('.html', '');
                return {
                    tn: templateName,
                    tp: templateImageMap[templateName] || "" // No fallback, return empty string if not found
                };
            });

        res.status(200).json(templates);
    });
});

export default router;
