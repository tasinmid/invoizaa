import express from 'express';
import fs from 'fs/promises'; // Use fs.promises for async file operations
import path from 'path';
import { browser } from '../app.js'; // Import the shared browser instance

const router = express.Router();

// Define the templates directory path
const templatesDir = path.resolve(process.cwd(), 'templates');

router.post('/', async (req, res) => { // Made the route handler async
  const { tp, cp, ad, ph, sn, dt, pm, an, st, il, it, re, pl, bt } = req.body;

  // ... (existing validation logic remains the same) ...
  if (!tp || !cp || !ad || !ph || !pm || !il || !it) {
    return res.status(400).json({ status: 'invalid', message: 'Missing required fields' });
  }

  if (!['ot', 'mp'].includes(it)) {
    return res.status(400).json({ status: 'invalid', message: 'Invalid invoice type (it)' });
  }

  if (!Array.isArray(il) || il.length === 0) {
    return res.status(400).json({ status: 'invalid', message: 'Invoice list (il) must be a non-empty array' });
  }

  for (const item of il) {
    if (it === 'ot') {
      if (!item.nm || !item.qt || !item.up) {
        return res.status(400).json({ status: 'invalid', message: 'Each one-time invoice item must have nm, qt, and up' });
      }
    } else if (it === 'mp') {
      if (!item.nm || !item.mr || !Array.isArray(item.mr) || item.mr.length === 0 || !item.pm) {
        return res.status(400).json({ status: 'invalid', message: 'Each monthly invoice item must have nm, non-empty mr (array), and pm' });
      }
    }
  }

  const sendType = st || 'dl';
  if (!['ep', 'eh', 'dl'].includes(sendType)) {
    return res.status(400).json({ status: 'invalid', message: 'Invalid send type' });
  }

  // Validate recipient email if send type is email
  if ((sendType === 'ep' || sendType === 'eh') && (!re || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(re))) {
    return res.status(400).json({ status: 'invalid', message: 'Recipient email (re) is required and must be valid for email send types' });
  }

  const responseData = {
    tp,
    cp,
    ad,
    ph,
    bt,
    sn: sn || `INV${Math.floor(1000 + Math.random() * 9000)}`,
    dt: dt || new Date().toISOString().split('T')[0],
    pm,
    an,
    st: sendType,
    il: il,
    it: it,
    re: re,
    pl: pl
  };

  if (pm.t === 'pp') {
    if (!pm.em || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(pm.em)) {
      return res.status(400).json({ status: 'invalid', message: 'A valid PayPal email (em) is required' });
    }
  } else if (pm.t === 'pl') {
    if (!pl || !/^https?:\/\/.+/.test(pl)) {
      return res.status(400).json({ status: 'invalid', message: 'A valid Payment Link (pl) is required' });
    }
  } else if (pm.t === 'bd') {
    if (!pm.bn || !pm.sc || !pm.an || !pm.rn || !pm.br) {
      return res.status(400).json({ status: 'invalid', message: 'Missing bank details (bn, sc, an, rn, br)' });
    }
    if (!/^[A-Za-z]{8,11}$/.test(pm.sc)) {
      return res.status(400).json({ status: 'invalid', message: 'Swift Code (sc) must be 8-11 letters' });
    }
  } else if (pm.t !== 'other') {
    return res.status(400).json({ status: 'invalid', message: 'Invalid payment method type' });
  }

  // PDF Generation Logic
  if (sendType === 'dl') {
    let page;
    try {
      // 1. Read the HTML template and the global JS file
      const templatePath = path.join(templatesDir, `${tp}.html`);
      const globalJsPath = path.join(templatesDir, 'global.js');

      let htmlContent = await fs.readFile(templatePath, 'utf8');
      const globalJsContent = await fs.readFile(globalJsPath, 'utf8');

      // 2. Inject the full data payload and the global script into the HTML
      htmlContent = htmlContent.replace('{{INVOICE_DATA_JSON}}', JSON.stringify(responseData));
      htmlContent = htmlContent.replace('// {{GLOBAL_SCRIPT}}', globalJsContent);

      // 3. Use the shared browser instance to create a new page
      page = await browser.newPage();
      await page.setContent(htmlContent, { waitUntil: 'networkidle0' });

      const pdf = await page.pdf({ format: 'A4', printBackground: true });

      // 4. Send the generated PDF as a response
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename=${responseData.sn}.pdf`);
      return res.send(pdf);

    } catch (error) {
      console.error('Error generating PDF:', error);
      return res.status(500).json({ status: 'error', message: 'Failed to generate PDF', error: error.message });
    } finally {
      if (page) {
        await page.close();
      }
    }
  }

  // For other send types, just mirror the data (existing logic)
  res.status(200).json({ status: 'valid', data: responseData });
});

export default router;