import express from 'express';
import cors from 'cors';
import puppeteer from 'puppeteer';
import apiRoutes from './routes/apiRoutes.js';
import templateRoutes from './routes/templateRoutes.js';

// --- Puppeteer Browser Instance ---
console.log('Launching a shared Puppeteer browser instance...');
const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
});
console.log('Puppeteer browser instance launched successfully.');

// Gracefully close the browser on exit
const cleanup = async () => {
    console.log('Closing the Puppeteer browser instance...');
    await browser.close();
    process.exit(0);
};

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);


const app = express();

// Middleware to log incoming requests
const getProcessName = (method, url) => {
  if (method === 'POST' && url === '/') {
    return 'Invoice Generation/Processing';
  }
  if (method === 'GET' && url === '/l') {
    return 'Template Listing';
  }
  return 'General Request';
};

const loggingMiddleware = (req, res, next) => {
  const processName = getProcessName(req.method, req.originalUrl);
  // Use 'x-forwarded-for' header if behind a proxy, otherwise fall back to remoteAddress
  const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  const logMessage = `[${new Date().toISOString()}] LOG: IP=${clientIp} | Process='${processName}' | Request='${req.method} ${req.originalUrl}'`;
  console.log(logMessage);
  next(); // Pass control to the next handler in the chain
};

// Enable trust proxy to ensure req.ip is reliable if you are behind a reverse proxy (like Nginx or Heroku)
app.set('trust proxy', true);

app.use(cors());
app.use(express.json());

// Your API routes
app.use(loggingMiddleware, apiRoutes);
app.use(loggingMiddleware, templateRoutes);

export { app, browser };