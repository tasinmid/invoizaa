document.addEventListener('DOMContentLoaded', () => {
    // Check if invoiceData exists
    if (typeof invoiceData === 'undefined') {
        console.error('Invoice data is not available.');
        document.body.innerHTML = '<h1>Error: Invoice data not found.</h1>';
        return;
    }

    // --- Populate Header Info ---
    document.getElementById('company-name').textContent = invoiceData.cp || 'Your Company';
    document.getElementById('company-address').textContent = invoiceData.ad || 'Your Address';
    document.getElementById('company-phone').textContent = invoiceData.ph || 'Your Phone';
    document.getElementById('invoice-serial').textContent = invoiceData.sn || 'N/A';
    document.getElementById('invoice-date').textContent = invoiceData.dt || 'N/A';

    // --- Populate Billing Info ---
    const recipientInfoDiv = document.getElementById('recipient-info');
    const billTo = invoiceData.bt;
    if (billTo && (billTo.cp || billTo.ad || billTo.ph)) {
        let content = '<h4>Bill To:</h4>';
        if (billTo.cp) content += `<p><strong>${billTo.cp}</strong></p>`;
        if (billTo.ad) content += `<p>${billTo.ad}</p>`;
        if (billTo.ph) content += `<p>${billTo.ph}</p>`;
        recipientInfoDiv.innerHTML = content;
    } else {
        recipientInfoDiv.innerHTML = '<h4>Bill To:</h4><p>N/A</p>';
    }

    // --- Populate Invoice Items Table ---
    const table = document.getElementById('invoice-items');
    const thead = table.createTHead();
    const tbody = table.createTBody();
    const headerRow = thead.insertRow();

    let subtotal = 0;

    // Dynamically set table headers based on invoice type (it)
    let headers = [];
    if (invoiceData.it === 'mp') { // Monthly Payment
        headers = ['Item Name', 'Months', 'Price/Month', 'Total'];
    } else { // One-Time (ot) or default
        headers = ['Item Name', 'Quantity', 'Unit Price', 'Total'];
    }
    headers.forEach(headerText => {
        const th = document.createElement('th');
        th.textContent = headerText;
        headerRow.appendChild(th);
    });

    // Populate table rows and calculate subtotal
    invoiceData.il.forEach(item => {
        const row = tbody.insertRow();
        if (invoiceData.it === 'mp') {
            const price = parseFloat(item.pm) || 0;
            const months = Array.isArray(item.mr) ? item.mr : [];
            const total = price * months.length;
            subtotal += total;

            row.insertCell().textContent = item.nm || '';
            row.insertCell().textContent = months.join(', ');
            row.insertCell().textContent = price.toFixed(2);
            row.insertCell().textContent = total.toFixed(2);
        } else {
            const quantity = item.qt || 0;
            const unitPrice = item.up || 0;
            const total = quantity * unitPrice;
            subtotal += total;

            row.insertCell().textContent = item.nm || '';
            row.insertCell().textContent = quantity;
            row.insertCell().textContent = unitPrice.toFixed(2);
            row.insertCell().textContent = total.toFixed(2);
        }
    });

    // --- Calculate and Populate Totals ---
    const totalDue = subtotal;

    document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('total-due').textContent = `$${totalDue.toFixed(2)}`;


    // --- Populate Payment Information ---
    const paymentDiv = document.getElementById('payment-info');
    let paymentHTML = '<h4>Payment Information</h4>';
    const pm = invoiceData.pm;
    if (pm) {
        switch (pm.t) {
            case 'pp':
                paymentHTML += `<p><strong>PayPal:</strong> ${pm.em || 'N/A'}</p>`;
                break;
            case 'pl':
                paymentHTML += `<p><strong>Payment Link:</strong> <a href="${invoiceData.pl || '#'}">${invoiceData.pl || 'N/A'}</a></p>`;
                break;
            case 'bd':
                paymentHTML += `
                    <p><strong>Bank Name:</strong> ${pm.bn || 'N/A'}</p>
                    <p><strong>SWIFT Code:</strong> ${pm.sc || 'N/A'}</p>
                    <p><strong>Account Number:</strong> ${pm.an || 'N/A'}</p>
                    <p><strong>Routing Number:</strong> ${pm.rn || 'N/A'}</p>
                    <p><strong>Branch:</strong> ${pm.br || 'N/A'}</p>
                `;
                if (pm.ai) {
                    paymentHTML += `<p><strong>Additional Details:</strong> ${pm.ai}</p>`;
                }
                break;
            case 'other':
                paymentHTML += `<p>${pm.d || 'Details not provided.'}</p>`;
                break;
        }
    }
    paymentDiv.innerHTML = paymentHTML;

    // --- Populate Additional Notes ---
    const notesDiv = document.getElementById('additional-notes');
    if (invoiceData.an) {
        notesDiv.innerHTML = `<h4>General Invoice Notes</h4><p>${invoiceData.an}</p>`;
    }
});
